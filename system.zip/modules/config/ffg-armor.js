export const armor_stats = {
  "defence": {
    value: "defence",
    label: "SWFFG.Defense",
  },
  "soak": {
    value: "soak",
    label: "SWFFG.ItemsSoak",
  },
  "encumbrance": {
    value: "encumbrance",
    label: "SWFFG.ItemsEncum",
  },
  "hardpoints": {
    value: "hardpoints",
    label: "SWFFG.ItemsHP",
  },
  "rarity": {
    value: "rarity",
    label: "SWFFG.ItemsRarity",
  },
  "price": {
    value: "price",
    label: "SWFFG.ItemsPrice",
  },
};
